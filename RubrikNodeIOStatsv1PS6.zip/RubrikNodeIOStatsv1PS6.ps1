﻿########################################################################################################################
# Start of the script - Description, Requirements & Legal Disclaimer
########################################################################################################################
# Written by: Joshua Stenhouse joshuastenhouse@gmail.com
################################################
# Description:
# This script gives you realtime CPU and network stats from your Rubrik cluster.  
################################################ 
# Requirements:
# - A script directory and Rubrik cluster variable
# - PowerShell 6.x+
# - A Rubrik cluster or EDGE appliance, network access to it and credentials to login
# - The script automatically discovers the nodes in your rubrik cluster, you just have to specify 1 of them for it to work
################################################
# Legal Disclaimer:
# This script is written by Joshua Stenhouse is not supported under any support program or service. 
# All scripts are provided AS IS without warranty of any kind. 
# The author further disclaims all implied warranties including, without limitation, any implied warranties of merchantability or of fitness for a particular purpose. 
# The entire risk arising out of the use or performance of the sample scripts and documentation remains with you. 
# In no event shall its authors, or anyone else involved in the creation, production, or delivery of the scripts be liable for any damages whatsoever 
# (including, without limitation, damages for loss of business profits, business interruption, loss of business information, or other pecuniary loss) arising out of the use of or inability to use the sample scripts or documentation, 
# even if the author has been advised of the possibility of such damages.
################################################
# Configure the variables below for the Rubrik Cluster
################################################
$RubrikCluster = "192.168.1.201"
$ScriptDirectory = "C:\Users\joshu\OneDrive\Rubrik\#Scripts\RubrikNodeIOStatsv1\"
$AutoRefresh = $TRUE
########################################################################################################################
# Nothing to configure below this line - Starting the main function of the script
########################################################################################################################
###############################################
# Prompting for Rubrik credentials
###############################################
$RubrikCredentials = Get-Credential -Message "Enter Rubrik login credentials"
# Setting the username and password for authentication
$RubrikUser = $RubrikCredentials.UserName
$RubrikPassword = $RubrikCredentials.GetNetworkCredential().Password
###############################################
# Building Rubrik API string & invoking REST API
###############################################
$BaseURL = "https://" + $RubrikCluster + "/api/v1/"
$InternalURL = "https://" + $RubrikCluster + "/api/internal/"
$RubrikSessionURL = $BaseURL + "session"
$Header = @{"Authorization" = "Basic "+[System.Convert]::ToBase64String([System.Text.Encoding]::UTF8.GetBytes($RubrikUser+":"+$RubrikPassword))}
$Type = "application/json"
# Authenticating with API
Try 
{
$RubrikSessionResponse = Invoke-RestMethod -Uri $RubrikSessionURL -Headers $Header -Method POST -ContentType $Type -SkipCertificateCheck
$RubrikSessionSuccess = $TRUE
}
Catch 
{
$RubrikSessionSuccess = $FALSE
$_.Exception.ToString()
$Error[0] | Format-List -Force
}
# Extracting the token from the JSON response
$RubrikSessionHeader = @{'Authorization' = "Bearer $($RubrikSessionResponse.token)"}
##################################
# Getting Node Info
##################################
$NodeListURL = $InternalURL+"cluster/me/network_interface"
Try 
{
$NodeListJSON = Invoke-RestMethod -Uri $NodeListURL -Headers $RubrikSessionHeader -ContentType $Type -TimeoutSec 100 -SkipCertificateCheck
$NodeList = $NodeListJSON.data
}
Catch 
{
$_.Exception.ToString()
$Error[0] | Format-List -Force
}
$NodeInfoTable = @()
# Selecting management interfaces
$NodeListFiltered = $NodeList | Where-Object {$_.interfaceType -ne "Service"}
# For Each Node getting IPs
ForEach ($Node in $NodeListFiltered)
{
$NodeName = $Node.node
$NodeInterface = $Node.interfaceType
$NodeInterfaceName = $Node.interfaceName
$NodeIPs = $Node.ipAddresses
$NodePhysicalIP = $NodeIPs | Select -First 1
$NodeVirtualIPs = $NodeIPs | Select -Skip 1
$NodeVirtualIPsCount = $NodeVirtualIPs.Count
# Adding to array
$NodeInfoTableRow = New-Object PSObject
$NodeInfoTableRow | Add-Member -MemberType NoteProperty -Name "Name" -Value "$NodeName"
$NodeInfoTableRow | Add-Member -MemberType NoteProperty -Name "Interface" -Value "$NodeInterface"
$NodeInfoTableRow | Add-Member -MemberType NoteProperty -Name "InterfaceName" -Value "$NodeInterfaceName"
$NodeInfoTableRow | Add-Member -MemberType NoteProperty -Name "PhysicalIP" -Value "$NodePhysicalIP"
$NodeInfoTableRow | Add-Member -MemberType NoteProperty -Name "VitualIPSAssigned" -Value "$NodeVirtualIPsCount"
$NodeInfoTableRow | Add-Member -MemberType NoteProperty -Name "VirtualIPs" -Value "$NodeVirtualIPs"
$NodeInfoTable += $NodeInfoTableRow
}
##################################
# Repeating Query If $AutoRefresh -eq $TRUE
##################################
Do
{
##########################
# Getting current time
##########################
$SystemDateTime = Get-Date
##################################
# ForEach Node Getting IO Stats
##################################
# Creating array
$NodeStatsTable = @()
# ForEachNode
ForEach ($Node in $NodeInfoTable)
{
# Setting variables
$NodeID = $Node.Name
$NodeIP = $Node.PhysicalIP
# Getting node stats
$NodeStatsURL = $InternalURL+"node/" + $NodeID + "/stats?range=-1h"
Try 
{
$NodeStats = Invoke-RestMethod -Uri $NodeStatsURL -Headers $RubrikSessionHeader -ContentType $Type -TimeoutSec 100 -SkipCertificateCheck
}
Catch 
{
$_.Exception.ToString()
$Error[0] | Format-List -Force
}
# Pulling stats
$NodeCpuStats = $NodeStats.cpuStat  | Sort-Object time -Descending
$NodeNetworkStats = $NodeStats.networkStat
# Pulling network stats
$NodeNetworkBytesReceived = $NodeNetworkStats.bytesReceived | Sort-Object time -Descending
$NodeNetworkBytesTransmitted = $NodeNetworkStats.bytesTransmitted | Sort-Object time -Descending
# ForEach CPUStat
$NodeRecordCount = 0
ForEach($NodeCpuStat in $NodeCpuStats)
{
$StatType = "CPU"
$Unit = "%"
$StatTime = $NodeCpuStat.time
$Stat = $NodeCpuStat.stat
# Incrementing counter
$NodeRecordCount ++
# Adding Network stats to array
$NodeStatsTableRow = New-Object PSObject
$NodeStatsTableRow | Add-Member -MemberType NoteProperty -Name "Node" -Value "$NodeID"
$NodeStatsTableRow | Add-Member -MemberType NoteProperty -Name "IP" -Value "$NodeIP"
$NodeStatsTableRow | Add-Member -MemberType NoteProperty -Name "Time" -Value "$StatTime"
$NodeStatsTableRow | Add-Member -MemberType NoteProperty -Name "ID" -Value "$NodeRecordCount"
$NodeStatsTableRow | Add-Member -MemberType NoteProperty -Name "Stat" -Value "$StatType"
$NodeStatsTableRow | Add-Member -MemberType NoteProperty -Name "Data" -Value "$Stat"
$NodeStatsTableRow | Add-Member -MemberType NoteProperty -Name "Unit" -Value "$Unit"
$NodeStatsTable += $NodeStatsTableRow
}
# ForEach NetworkBytesReceived Record
$NodeRecordCount = 0
ForEach ($NodeNetworkBytesReceivedStat in $NodenetworkBytesReceived)
{
$StatType = "Ingress"
$Unit = "MB/sec"
$StatTime = $NodeNetworkBytesReceivedStat.time
$StatBytes = $NodeNetworkBytesReceivedStat.stat
# Converting bytes to MB/sec
$StatMB = $StatBytes / 1000 / 1000
$StatMB = [Math]::Round($StatMB,2)
# Incrementing counter
$NodeRecordCount ++
# Adding Network stats to array
$NodeStatsTableRow = New-Object PSObject
$NodeStatsTableRow | Add-Member -MemberType NoteProperty -Name "Node" -Value "$NodeID"
$NodeStatsTableRow | Add-Member -MemberType NoteProperty -Name "IP" -Value "$NodeIP"
$NodeStatsTableRow | Add-Member -MemberType NoteProperty -Name "Time" -Value "$StatTime"
$NodeStatsTableRow | Add-Member -MemberType NoteProperty -Name "ID" -Value "$NodeRecordCount"
$NodeStatsTableRow | Add-Member -MemberType NoteProperty -Name "Stat" -Value "$StatType"
$NodeStatsTableRow | Add-Member -MemberType NoteProperty -Name "Data" -Value "$StatMB"
$NodeStatsTableRow | Add-Member -MemberType NoteProperty -Name "Unit" -Value "$Unit"
$NodeStatsTable += $NodeStatsTableRow
}
# ForEach NetworkBytesTransmitted Record
$NodeRecordCount = 0
ForEach ($NodeNetworkBytesTransmittedStat in $NodenetworkBytesTransmitted)
{
$StatType = "Egress"
$Unit = "MB/sec"
$StatTime = $NodeNetworkBytesTransmittedStat.time
$StatBytes = $NodeNetworkBytesTransmittedStat.stat
# Converting bytes to MB/sec
$StatMB = $StatBytes / 1000 / 1000
$StatMB = [Math]::Round($StatMB,2)
# Incrementing counter
$NodeRecordCount ++
# Adding Network stats to array
$NodeStatsTableRow = New-Object PSObject
$NodeStatsTableRow | Add-Member -MemberType NoteProperty -Name "Node" -Value "$NodeID"
$NodeStatsTableRow | Add-Member -MemberType NoteProperty -Name "IP" -Value "$NodeIP"
$NodeStatsTableRow | Add-Member -MemberType NoteProperty -Name "Time" -Value "$StatTime"
$NodeStatsTableRow | Add-Member -MemberType NoteProperty -Name "ID" -Value "$NodeRecordCount"
$NodeStatsTableRow | Add-Member -MemberType NoteProperty -Name "Stat" -Value "$StatType"
$NodeStatsTableRow | Add-Member -MemberType NoteProperty -Name "Data" -Value "$StatMB"
$NodeStatsTableRow | Add-Member -MemberType NoteProperty -Name "Unit" -Value "$Unit"
$NodeStatsTable += $NodeStatsTableRow
}
# End of action per node below
}
# End of action per node above
##################################
# Getting latest node stats
##################################
$LatestNodeStats = $NodeStatsTable | Where-Object {$_.ID -eq "1"} 
##################################
# Calculating cluster stats over time
##################################
$ClusterStatsTable = @()
# Current stats
$CurrentCPULoad = $NodeStatsTable | Where-Object {(($_.ID -eq "1") -And ($_.Stat -eq "CPU"))} | Select -ExpandProperty Data | Measure -Average | Select -ExpandProperty Average
$CurrentMBSecReceived = $NodeStatsTable | Where-Object {(($_.ID -eq "1") -And ($_.Stat -eq "Ingress"))} | Select -ExpandProperty Data | Measure -Sum | Select -ExpandProperty Sum
$CurrentMBSecTransmitted = $NodeStatsTable | Where-Object {(($_.ID -eq "1") -And ($_.Stat -eq "Egress"))} | Select -ExpandProperty Data | Measure -Sum | Select -ExpandProperty Sum
# Rounding
$CurrentCPULoad = [Math]::Round($CurrentCPULoad,0)
$CurrentMBSecReceived = [Math]::Round($CurrentMBSecReceived,2)
$CurrentMBSecTransmitted = [Math]::Round($CurrentMBSecTransmitted,2)
# Adding results to a table array for ease of reading
$ClusterStatsTableRow = New-Object PSObject
$ClusterStatsTableRow | Add-Member -MemberType NoteProperty -Name "Cluster" -Value "Current"
$ClusterStatsTableRow | Add-Member -MemberType NoteProperty -Name "CPU" -Value "$CurrentCPULoad"
$ClusterStatsTableRow | Add-Member -MemberType NoteProperty -Name "MBReceived" -Value "$CurrentMBSecReceived"
$ClusterStatsTableRow | Add-Member -MemberType NoteProperty -Name "MBTransmitted" -Value "$CurrentMBSecTransmitted"
$ClusterStatsTable += $ClusterStatsTableRow
# Average over the time period
$AverageCPULoad = $NodeStatsTable | Where-Object {($_.Stat -eq "CPU")} | Select -ExpandProperty Data | Measure -Average | Select -ExpandProperty Average
$AverageMBSecReceived = $NodeStatsTable | Where-Object {($_.Stat -eq "Ingress")} | Select -ExpandProperty Data | Measure -Average | Select -ExpandProperty Average
$AverageMBSecTransmitted = $NodeStatsTable | Where-Object {($_.Stat -eq "Egress")} | Select -ExpandProperty Data | Measure -Average | Select -ExpandProperty Average
# Rounding
$AverageCPULoad = [Math]::Round($AverageCPULoad,0)
$AverageMBSecReceived = [Math]::Round($AverageMBSecReceived,2)
$AverageMBSecTransmitted = [Math]::Round($AverageMBSecTransmitted,2)
# Adding results to a table array for ease of reading
$ClusterStatsTableRow = New-Object PSObject
$ClusterStatsTableRow | Add-Member -MemberType NoteProperty -Name "Cluster" -Value "Average"
$ClusterStatsTableRow | Add-Member -MemberType NoteProperty -Name "CPU" -Value "$AverageCPULoad"
$ClusterStatsTableRow | Add-Member -MemberType NoteProperty -Name "MBReceived" -Value "$AverageMBSecReceived"
$ClusterStatsTableRow | Add-Member -MemberType NoteProperty -Name "MBTransmitted" -Value "$AverageMBSecTransmitted"
$ClusterStatsTable += $ClusterStatsTableRow
##################################
# Showing results to user
##################################
# Cluster stats
"
Stats @ $SystemDateTime
"
$ClusterStatsTable | Format-Table -AutoSize
# Per node stats
$LatestNodeStats | Sort-Object Stat | Select Node,IP,Stat,Data,Unit | Format-Table -AutoSize
##################################
# End of Repeating Query If $AutoRefresh -eq $TRUE
##################################
}
Until($AutoRefresh -eq $False)
###############################################
# End of script
###############################################