﻿########################################################################################################################
# Start of the script - Description, Requirements & Legal Disclaimer
########################################################################################################################
# Written by: Joshua Stenhouse joshuastenhouse@gmail.com
################################################
# Description:
# This script monitors the status of the Rubrik nodes in your cluster
################################################ 
# Requirements:
# - Run the RubrikSQLExportv1-Auth.ps1 to secure your Rubrik credentials, this script won't work without this being run first
# - Run PowerShell as administrator with command "Set-ExecutionPolcity unrestricted" on the host running the script
# - A Rubrik cluster or EDGE appliance, network access to it and credentials to login
# - A Variable specifying the IP or DNS name of one, multiple, or all the Rubrik nodes in your cluster 
# - The variable doesn't have to be every node, but I recommend putting a few in here if not all. The script tests a ping to each to decide which to use to authenticate with the API to get the status of all nodes. 
# - This stops the script being tied to an individual node and failing because you happended to try login to the node that was down. This can be IPs or individual DNS names for each node.
################################################
# Legal Disclaimer:
# This script is written by Joshua Stenhouse is not supported under any support program or service. 
# All scripts are provided AS IS without warranty of any kind. 
# The author further disclaims all implied warranties including, without limitation, any implied warranties of merchantability or of fitness for a particular purpose. 
# The entire risk arising out of the use or performance of the sample scripts and documentation remains with you. 
# In no event shall its authors, or anyone else involved in the creation, production, or delivery of the scripts be liable for any damages whatsoever 
# (including, without limitation, damages for loss of business profits, business interruption, loss of business information, or other pecuniary loss) arising out of the use of or inability to use the sample scripts or documentation, 
# even if the author has been advised of the possibility of such damages.
################################################
# Configure the variables below for the Rubrik Cluster
################################################
$RubrikNodes = "192.168.1.201","192.168.1.202","192.168.1.203","192.168.1.204"
$ScriptDirectory = "C:\RubrikNodeMonitoringv1\"
########################################################################################################################
# Nothing to configure below this line - Starting the main function of the script
########################################################################################################################
###############################################
# Pinging nodes to find working node to login to
###############################################
$NodePingResult = @()
ForEach ($_ in $RubrikNodes)
{
$NodePingTest = Test-Connection $_ -Count 2 -Quiet 
# Adding result
$NodePingResultLine = New-Object PSObject
$NodePingResultLine | Add-Member -MemberType NoteProperty -Name "Node" -Value "$_"
$NodePingResultLine | Add-Member -MemberType NoteProperty -Name "Ping" -Value "$NodePingTest"
$NodePingResult += $NodePingResultLine
}
# Selecting first active node 
$RubrikLoginNode = $NodePingResult | Where-Object {$_.Ping -eq $True} | Select -ExpandProperty Node -First 1
# If all dead, bypassing login and setting cluster status to bad
IF ($RubrikLoginNode -eq $null)
{
# Setting error details
$errorDetails = "No Rubrik Nodes Responded To Pings"
}
ELSE
{
###############################################
# Importing Rubrik credentials
###############################################
# Setting credential file
$RubrikCredentialsFile = $ScriptDirectory + "RubrikCredentials.xml"
# Testing if file exists
$RubrikCredentialsFileTest =  Test-Path $RubrikCredentialsFile
# IF doesn't exist, prompting and saving credentials
IF ($RubrikCredentialsFileTest -eq $False)
{
$RubrikCredentials = Get-Credential -Message "Enter Rubrik login credentials"
$RubrikCredentials | EXPORT-CLIXML $RubrikCredentialsFile -Force
}
# Importing credentials
$RubrikCredentials = IMPORT-CLIXML $RubrikCredentialsFile
# Setting the username and password from the credential file (run at the start of each script)
$RubrikUser = $RubrikCredentials.UserName
$RubrikPassword = $RubrikCredentials.GetNetworkCredential().Password
##################################
# Adding certificate exception and TLS 1.2 to prevent API errors
##################################
add-type @"
    using System.Net;
    using System.Security.Cryptography.X509Certificates;
    public class TrustAllCertsPolicy : ICertificatePolicy {
        public bool CheckValidationResult(
            ServicePoint srvPoint, X509Certificate certificate,
            WebRequest request, int certificateProblem) {
            return true;
        }
    }
"@
[System.Net.ServicePointManager]::CertificatePolicy = New-Object TrustAllCertsPolicy
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
###############################################
# Building Rubrik API string & invoking REST API
###############################################
$BaseURL = "https://" + $RubrikLoginNode + "/api/v1/"
$InternalURL = "https://" + $RubrikLoginNode + "/api/internal/"
$RubrikSessionURL = $BaseURL + "session"
$Header = @{"Authorization" = "Basic "+[System.Convert]::ToBase64String([System.Text.Encoding]::UTF8.GetBytes($RubrikUser+":"+$RubrikPassword))}
$Type = "application/json"
# Authenticating with API
Try 
{
$RubrikSessionResponse = Invoke-RestMethod -Uri $RubrikSessionURL -Headers $Header -Method POST -ContentType $Type
$RubrikSessionSuccess = $TRUE
}
Catch 
{
$RubrikSessionSuccess = $FALSE
$_.Exception.ToString()
$Error[0] | Format-List -Force
}
# Extracting the token from the JSON response
$RubrikSessionHeader = @{'Authorization' = "Bearer $($RubrikSessionResponse.token)"}
###############################################
# Failback Rubrik API string & invoking REST API
###############################################
# IF the session request fails, trying another node just in case the node pinged, but isn't responding to API calls (could also just be incorrect credentials!)
IF ($RubrikSessionSuccess -eq $FALSE)
{
$RubrikLoginNode = $NodePingResult | Where-Object {$_.Ping -eq $True} | Select -ExpandProperty Node -Last 1
$BaseURL = "https://" + $RubrikLoginNode + "/api/v1/"
$InternalURL = "https://" + $RubrikLoginNode + "/api/internal/"
# Authenticating with API
Try 
{
$RubrikSessionResponse = Invoke-RestMethod -Uri $RubrikSessionURL -Headers $Header -Method POST -ContentType $Type
$ErrorDetails = $null
}
Catch 
{
$_.Exception.ToString()
$Error[0] | Format-List -Force
# Finding a username/password error
$ErrorDetails = $Error[0] | Select -ExpandProperty errorDetails | ConvertFrom-JSON | Select -ExpandProperty Message
}
# Output to host
IF ($ErrorDetails -eq "Incorrect username/password")
{
"---------------------------
WARNING: Incorrect Username and password!
---------------------------"
}
# Extracting the token from the JSON response
$RubrikSessionHeader = @{'Authorization' = "Bearer $($RubrikSessionResponse.token)"}
}
# End of "IF all IPs are bad, not trying to login" below
}
# End of "IF all IPs are bad, not trying to login" above
###############################################
# IF no session header exists stopping the script API calls here, otherwise, continuing
###############################################
IF (($RubrikSessionResponse.token -eq $null) -OR ($RubrikLoginNode -eq $null))
{
$ClusterStatus = "Down"
# Output to host
"---------------------------
WARNING! ClusterStatus: $ClusterStatus
---------------------------"
"Either you specified incorrect credentials, rubrik node IPs, or your cluster has gone TITSUP (Total Inability To Support Usual Performance)"
"errorMessage: $errorDetails" 
}
ELSE
{
#Continuing script
###############################################
# Getting list of Nodes
###############################################
$NodeListURL = $InternalURL+"node"
Try 
{
$NodeListJSON = Invoke-RestMethod -Uri $NodeListURL -TimeoutSec 100 -Headers $RubrikSessionHeader -ContentType $Type
$NodeList = $NodeListJSON.data
}
Catch 
{
$_.Exception.ToString()
$Error[0] | Format-List -Force
}
###############################################
# Getting detailed information for each node, adding result to table
###############################################
$RubrikNodeStatus = @()
$RubrikHDDStatus = @()
ForEach ($Node in $NodeList)
{
# Setting node variables
$NodeID = $Node.id
$NodeStatus = $Node.status
$NodeIP = $Node.ipAddress
$NodeNeedsInspection = $Node.needsInspection
$NodeSupportTunnel = $Node.supportTunnel | Select -ExpandProperty isTunnelEnabled
###############################################
# Getting Node detailed info, if not already indicated as BAD by the cluster
###############################################
IF ($NodeStatus -ne "BAD")
{
$NodeInfoURL = $InternalURL+"node/"+$NodeID
Try 
{
$NodeInfo = Invoke-RestMethod -Uri $NodeInfoURL -TimeoutSec 100 -Headers $RubrikSessionHeader -ContentType $Type
$errorDetails = $null
}
Catch 
{
$_.Exception.ToString()
$Error[0] | Format-List -Force
# Capturing error message
$ErrorDetails = $Error[0] | Select -ExpandProperty errorDetails | Select -ExpandProperty Message
}
###############################################
# IF Node check has failed, waiting 180 seconds and trying again before setting to bad
###############################################
# This is needed because a node could fail and the cluster hasn't picked it up yet, so waiting and trying again verifies it is truly bad
# By waiting 3 minutes this is enough time for the node to finish rebooting if it was indeed maintenance
IF ($errorDetails -eq "The server is currently unavailable (because it is overloaded or down for maintenance).")
{
"Recieved error message on Node: $NodeID
Waiting 3 minutes before trying one more time. Setting node as BAD if no response again"
sleep 180
# Trying the node again
Try 
{
$NodeInfo = Invoke-RestMethod -Uri $NodeInfoURL -TimeoutSec 100 -Headers $RubrikSessionHeader -ContentType $Type
$ErrorDetails = $null
}
Catch 
{
$_.Exception.ToString()
$Error[0] | Format-List -Force
# Capturing error message
$ErrorDetails = $Error[0] | Select -ExpandProperty errorDetails | Select -ExpandProperty Message
}
}
# End of if node status equals BAD below
}
# End of if node status equals BAD above
###############################################
# Setting Node status to Bad if still not responding to API calls
###############################################
IF (($errorDetails -eq "The server is currently unavailable (because it is overloaded or down for maintenance).") -OR ($NodeStatus -eq "BAD"))
{
$NodeStatus = "BAD"
$NodeNeedsInspection = "True"
# Nulling out all over values, as they are from the previous node
$NodeNetworkSpeed = $null
$NodeCores = $null
$NodeRAM = $null
$NodeSupportTunnelPort = $null
$NodeSSDStatus = $null
$NodeSSDCapacityGB = $null
$NodeSSDUsableGB = $null
$NodeSSDUsedGB = $null
$NodeSSDUsedPercentage = $null 
$NodeHDDEncrypted = $null
$NodeAvailableTB = $null
$NodeUsedTB = $null
$NodeUsedPercentage = $null
$NodeAvailableTB = $null
$NodeSSDEncrypted = $null
$NodeSupportTunnel = $null
$NodeHDDCount = $null
$NodeHDDActive = $null
$NodeHDDFailed = $null
$NodeHDDEncrypted = $null
$NodeCapacityTB = $null
}
ELSE
{
###############################################
# Node is OK, continune to process $NodeInfo
###############################################
# Setting node detail variables
$NodeNetworkSpeed = $NodeInfo.networkSpeed
$NodeCores = $NodeInfo.cpuCores
$NodeRAM = $NodeInfo.ram
# Converting RAM to GB
$NodeRAM = $NodeRAM / 1000 / 1000 / 1000
$NodeRAM = [Math]::Round($NodeRAM,0)
# Getting tunnel port if enabled
IF ($NodeSupportTunnel -eq $TRUE)
{
$NodeSupportTunnelPort = $NodeInfo.supportTunnel | Select -ExpandProperty Port
}
ELSE
{
$NodeSupportTunnelPort = $NULL
}
###############################################
# Settting SSD info
###############################################
$NodeSSDStatus = $NodeInfo.ssd | Select -ExpandProperty status
$NodeSSDCapacityBytes = $NodeInfo.ssd | Select -ExpandProperty capacityBytes
$NodeSSDUsableBytes = $NodeInfo.ssd | Select -ExpandProperty usableBytes
$NodeSSDEncrypted = $NodeInfo.ssd | Select -ExpandProperty isEncrypted
# Converting Bytes to GB
$NodeSSDCapacityGB = $NodeSSDCapacityBytes / 1000 / 1000 / 1000
$NodeSSDCapacityGB = [Math]::Round($NodeSSDCapacityGB,0)
$NodeSSDUsableGB = $NodeSSDUsableBytes / 1000 / 1000 / 1000
$NodeSSDUsableGB = [Math]::Round($NodeSSDUsableGB,0)
# Cacluating used
$NodeSSDUsedGB = $NodeSSDCapacityGB - $NodeSSDUsableGB
# Getting percentage
$NodeSSDUsedPercentage = ($NodeSSDUsedGB/$NodeSSDCapacityGB).tostring("P1")
###############################################
# Settting HDD info
###############################################
$NodeHDD = $NodeInfo.hdd
$NodeHDDCount = $NodeHDD.count
$NodeHDDActive = $NodeHDD | Where-Object {$_.status -eq "ACTIVE"} | Measure-Object | Select -ExpandProperty Count
$NodeHDDFailed = $NodeHDD | Where-Object {$_.status -ne "ACTIVE"} | Measure-Object | Select -ExpandProperty Count
$NodeHDDEncryptedCount = $NodeHDD | Where-Object {$_.isEncrypted -eq "True"} | Measure-Object | Select -ExpandProperty Count
# If all the HDDs are encrypted setting a blanked value of True, if one isn't then false
IF ($NodeHDDEncryptedCount -eq $NodeHDDCount)
{
$NodeHDDEncrypted = $TRUE
}
ELSE
{
$NodeHDDEncrypted = $FALSE
}
###############################################
# IF any failed disks in the node changing status to BAD
###############################################
IF ($NodeHDDFailed -gt 0)
{
$NodeStatus = "BAD"
$NodeNeedsInspection = "True"
}
###############################################
# For each HDD adding info to RubrikHDDStatus table
###############################################
$HDDNumber = 0
ForEach ($HDD in $NodeHDD)
{
$HDDNumber ++
# Setting HDD variables
$HDDStatus = $HDD.status
$HDDEncrypted = $HDD.isEncrypted
$HDDCapactityBytes = $HDD.capacityBytes
$HDDAvailableBytes = $HDD.usableBytes
$HDDPath = $HDD.path
# Converting Bytes to GB
$HDDCapactityGB = $HDDCapactityBytes / 1000 / 1000 / 1000
$HDDCapactityGB = [Math]::Round($HDDCapactityGB,0)
$HDDAvailableGB = $HDDAvailableBytes / 1000 / 1000 / 1000
$HDDAvailableGB = [Math]::Round($HDDAvailableGB,0)
# Calculating used space
$HDDUsedGB  = $HDDCapactityGB - $HDDAvailableGB
$HDDUsedGB = [Math]::Round($HDDUsedGB,0)
# Calculating percentage used space
$HDDUsedPercentage = ($HDDUsedGB/$HDDCapactityGB).tostring("P1")
# Adding result
$RubrikHDDStatusLine = new-object PSObject
$RubrikHDDStatusLine | Add-Member -MemberType NoteProperty -Name "Node" -Value "$NodeID"
$RubrikHDDStatusLine | Add-Member -MemberType NoteProperty -Name "Disk" -Value "$HDDNumber"
$RubrikHDDStatusLine | Add-Member -MemberType NoteProperty -Name "Status" -Value "$HDDStatus"
$RubrikHDDStatusLine | Add-Member -MemberType NoteProperty -Name "Encrypted" -Value "$HDDEncrypted"
$RubrikHDDStatusLine | Add-Member -MemberType NoteProperty -Name "RawCapacityGB" -Value $HDDCapactityGB
$RubrikHDDStatusLine | Add-Member -MemberType NoteProperty -Name "RawUsed" -Value $HDDUsedPercentage
$RubrikHDDStatusLine | Add-Member -MemberType NoteProperty -Name "RawUsedGB" -Value $HDDUsedGB
$RubrikHDDStatusLine | Add-Member -MemberType NoteProperty -Name "RawFreeGB" -Value $HDDAvailableGB
$RubrikHDDStatusLine | Add-Member -MemberType NoteProperty -Name "NodeIP" -Value "$NodeIP"
$RubrikHDDStatusLine | Add-Member -MemberType NoteProperty -Name "Path" -Value "$HDDPath"
$RubrikHDDStatus += $RubrikHDDStatusLine
}
###############################################
# Summarising Node capacity from the RubrikHDDStatus table
###############################################
$RubrikNodeHDDStatus = $RubrikHDDStatus | Where-Object {$_.Node -eq $NodeID}
# Summarising node HDD capacity
$NodeCapacityGB = 0
$NodeCapacityTB = 0
ForEach ($Disk in $RubrikNodeHDDStatus)
{
$DiskCapacityGB = $Disk.RawCapacityGB
$DiskCapacityGB = [int]$DiskCapacityGB
$NodeCapacityGB += $DiskCapacityGB
}
# Converting to TB
$NodeCapacityTB = $NodeCapacityGB / 1000
$NodeCapacityTB = [Math]::Round($NodeCapacityTB,2)
# Summarising node HDD Available
$NodeAvailableGB = 0
$NodeAvailableTB = 0
ForEach ($Disk in $RubrikNodeHDDStatus)
{
$DiskAvailableGB = $Disk.RawFreeGB
$DiskAvailableGB = [int]$DiskAvailableGB
$NodeAvailableGB += $DiskAvailableGB
}
# Converting to TB
$NodeAvailableTB = $NodeAvailableGB / 1000
$NodeAvailableTB = [Math]::Round($NodeAvailableTB,2)
# Summarising node HDD Used
$NodeUsedGB = 0
$NodeUsedTB = 0
ForEach ($Disk in $RubrikNodeHDDStatus)
{
$DiskUsedGB = $Disk.RawUsedGB
$DiskUsedGB = [int]$DiskUsedGB
$NodeUsedGB += $DiskUsedGB
}
# Converting to TB
$NodeUsedTB = $NodeUsedGB / 1000
$NodeUsedTB = [Math]::Round($NodeUsedTB,2)
# Calculating used space
$NodeUsedTB  = $NodeCapacityTB - $NodeAvailableTB
$NodeUsedTB = [Math]::Round($NodeUsedTB,2)
# Calculating percentage used space
$NodeUsedPercentage = ($NodeUsedTB/$NodeCapacityTB).tostring("P1")
}
###############################################
# Adding all node info to RubrikNodeStatus table of results
###############################################
$RubrikNodeStatusLine = New-Object PSObject
$RubrikNodeStatusLine | Add-Member -MemberType NoteProperty -Name "Node" -Value "$NodeID"
$RubrikNodeStatusLine | Add-Member -MemberType NoteProperty -Name "IP" -Value "$NodeIP"
$RubrikNodeStatusLine | Add-Member -MemberType NoteProperty -Name "Status" -Value "$NodeStatus"
$RubrikNodeStatusLine | Add-Member -MemberType NoteProperty -Name "NeedsInspection" -Value "$NodeNeedsInspection"
$RubrikNodeStatusLine | Add-Member -MemberType NoteProperty -Name "Cores" -Value $NodeCores
$RubrikNodeStatusLine | Add-Member -MemberType NoteProperty -Name "RAMGB" -Value "$NodeRAM"
$RubrikNodeStatusLine | Add-Member -MemberType NoteProperty -Name "NICSpeed" -Value "$NodeNetworkSpeed"
$RubrikNodeStatusLine | Add-Member -MemberType NoteProperty -Name "RawCapacityTB" -Value $NodeCapacityTB
$RubrikNodeStatusLine | Add-Member -MemberType NoteProperty -Name "RawUsed" -Value "$NodeUsedPercentage"
$RubrikNodeStatusLine | Add-Member -MemberType NoteProperty -Name "RawUsedTB" -Value $NodeUsedTB
$RubrikNodeStatusLine | Add-Member -MemberType NoteProperty -Name "RawFreeTB" -Value $NodeAvailableTB
$RubrikNodeStatusLine | Add-Member -MemberType NoteProperty -Name "SSD" -Value "$NodeSSDStatus"
$RubrikNodeStatusLine | Add-Member -MemberType NoteProperty -Name "SSDUsed" -Value "$NodeSSDUsedPercentage"
$RubrikNodeStatusLine | Add-Member -MemberType NoteProperty -Name "SSDEncrypted" -Value "$NodeSSDEncrypted"
$RubrikNodeStatusLine | Add-Member -MemberType NoteProperty -Name "HDDs" -Value $NodeHDDCount
$RubrikNodeStatusLine | Add-Member -MemberType NoteProperty -Name "HDDsActive" -Value $NodeHDDActive
$RubrikNodeStatusLine | Add-Member -MemberType NoteProperty -Name "HDDsFailed" -Value $NodeHDDFailed
$RubrikNodeStatusLine | Add-Member -MemberType NoteProperty -Name "HDDsEncrypted" -Value "$NodeHDDEncrypted"
$RubrikNodeStatusLine | Add-Member -MemberType NoteProperty -Name "SupportOpen" -Value "$NodeSupportTunnel"
$RubrikNodeStatusLine | Add-Member -MemberType NoteProperty -Name "TunnelPort" -Value $NodeSupportTunnelPort
$RubrikNodeStatus += $RubrikNodeStatusLine
# End of for each node action below
}
# End of for each node action above
###############################################
# Getting Cluster Info
###############################################
$ClusterInfoURL = $BaseURL+"cluster/me"
Try 
{
$ClusterInfo = Invoke-RestMethod -Uri $ClusterInfoURL -TimeoutSec 100 -Headers $RubrikSessionHeader -ContentType $Type
}
Catch 
{
$_.Exception.ToString()
$Error[0] | Format-List -Force
}
$ClusterVersion = $ClusterInfo.version
$ClusterName = $ClusterInfo.name
# Calculating cluster status based on nodes
$RubrikNodeCount = $RubrikNodeStatus.Count
$RubrikNodeHealthyCount = $RubrikNodeStatus | Where-Object {$_.Status -eq "OK"} | Measure-Object | Select -ExpandProperty Count
$RubrikNodeBadCount = $RubrikNodeStatus | Where-Object {$_.Status -ne "OK"} | Measure-Object | Select -ExpandProperty Count
# Conditional IF statement, if nodes reporting OK doesn't match total nodes in cluster then marking cluster degraded
IF (($RubrikNodeHealthyCount -ne $RubrikNodeCount) -or ($RubrikNodeBadCount -gt 0))
{
$ClusterStatus = "Degraded"
}
ELSE
{
$ClusterStatus = "OK"
}
###############################################
# Getting Cluster Storage Usage
###############################################
$ClusterStorageURL = $InternalURL+"stats/system_storage"
Try 
{
$ClusterStorage = Invoke-RestMethod -Uri $ClusterStorageURL -TimeoutSec 100 -Headers $RubrikSessionHeader -ContentType $Type
}
Catch 
{
$_.Exception.ToString()
$Error[0] | Format-List -Force
}
$ClusterTotalStorageBytes = $ClusterStorage.total
$ClusterUsedStorageBytes = $ClusterStorage.used
$ClusterFreeStorageBytes = $ClusterStorage.available
$ClusterLiveMountStorageBytes = $ClusterStorage.liveMount
# Converting to TB
$ClusterTotalStorageTB = $ClusterTotalStorageBytes / 1000 / 1000 / 1000 / 1000
$ClusterTotalStorageTB = [Math]::Round($ClusterTotalStorageTB,2)
$ClusterUsedStorageTB = $ClusterUsedStorageBytes / 1000 / 1000 / 1000 / 1000
$ClusterUsedStorageTB = [Math]::Round($ClusterUsedStorageTB,2)
$ClusterFreeStorageTB = $ClusterFreeStorageBytes / 1000 / 1000 / 1000 / 1000
$ClusterFreeStorageTB = [Math]::Round($ClusterFreeStorageTB,2)
# Converting to GB (doing used storage again for estimated runway
$ClusterLiveMountStorageGB = $ClusterLiveMountStorageBytes / 1000 / 1000 / 1000
$ClusterLiveMountStorageGB = [Math]::Round($ClusterLiveMountStorageGB,2)
$ClusterFreeStorageGB = $ClusterFreeStorageBytes / 1000 / 1000 / 1000
$ClusterFreeStorageGB = [Math]::Round($ClusterFreeStorageGB,2)
# Calculating percentage used space
$ClusterUsedPercentage = ($ClusterUsedStorageTB/$ClusterTotalStorageTB).tostring("P1")
###############################################
# Getting Cluster Cloud Storage Usage
###############################################
$CloudStorageURL = $InternalURL+"stats/cloud_storage/physical"
Try 
{
$CloudStorage = Invoke-RestMethod -Uri $CloudStorageURL -TimeoutSec 100 -Headers $RubrikSessionHeader -ContentType $Type
}
Catch 
{
$_.Exception.ToString()
$Error[0] | Format-List -Force
}
$ClusterCloudStorageBytes = $CloudStorage.value
# Converting to TB
$ClusterCloudStorageTB = $ClusterCloudStorageBytes / 1000 / 1000 / 1000 / 1000
$ClusterCloudStorageTB = [Math]::Round($ClusterCloudStorageTB,2)
###############################################
# Getting Cluster Storage Growth
###############################################
$StorageGrowthURL = $InternalURL+"stats/average_storage_growth_per_day"
Try 
{
$StorageGrowth = Invoke-RestMethod -Uri $StorageGrowthURL -TimeoutSec 100 -Headers $RubrikSessionHeader -ContentType $Type
}
Catch 
{
$_.Exception.ToString()
$Error[0] | Format-List -Force
}
$ClusterStorageGrowthBytes = $StorageGrowth.bytes
# Converting to GB
$ClusterStorageGrowthGB = $ClusterStorageGrowthBytes / 1000 / 1000 / 1000
$ClusterStorageGrowthGB = [Math]::Round($ClusterStorageGrowthGB,2)
# Estimated runway
$ClusterRunwayEstimate = $ClusterFreeStorageGB / $ClusterStorageGrowthGB
$ClusterRunwayEstimate = [Math]::Round($ClusterRunwayEstimate,0)
###############################################
# Adding Cluster info to table
###############################################
$RubrikClusterStatus = @()
$RubrikClusterStatus = new-object PSObject
$RubrikClusterStatus | Add-Member -MemberType NoteProperty -Name "Name" -Value "$ClusterName"
$RubrikClusterStatus | Add-Member -MemberType NoteProperty -Name "Status" -Value "$ClusterStatus"
$RubrikClusterStatus | Add-Member -MemberType NoteProperty -Name "Nodes" -Value $RubrikNodeCount
$RubrikClusterStatus | Add-Member -MemberType NoteProperty -Name "Bad" -Value $RubrikNodeBadCount 
$RubrikClusterStatus | Add-Member -MemberType NoteProperty -Name "Version" -Value "$ClusterVersion"
$RubrikClusterStatus | Add-Member -MemberType NoteProperty -Name "StorageTB" -Value $ClusterTotalStorageTB
$RubrikClusterStatus | Add-Member -MemberType NoteProperty -Name "Used" -Value "$ClusterUsedPercentage"
$RubrikClusterStatus | Add-Member -MemberType NoteProperty -Name "UsedTB" -Value $ClusterUsedStorageTB
$RubrikClusterStatus | Add-Member -MemberType NoteProperty -Name "FreeTB" -Value $ClusterFreeStorageTB
$RubrikClusterStatus | Add-Member -MemberType NoteProperty -Name "CloudTB" -Value $ClusterCloudStorageTB
$RubrikClusterStatus | Add-Member -MemberType NoteProperty -Name "LiveMountGB" -Value $ClusterLiveMountStorageGB
$RubrikClusterStatus | Add-Member -MemberType NoteProperty -Name "DailyGrowthGB" -Value $ClusterStorageGrowthGB
$RubrikClusterStatus | Add-Member -MemberType NoteProperty -Name "RunwayEstDays" -Value "$ClusterRunwayEstimate"
###############################################
# End of "IF no session header exists stopping the script API calls here, otherwise, continuing" below
###############################################
}
# End of "IF no session header exists stopping the script API calls here, otherwise, continuing" above
###############################################
# Output of Node, HDD, and Cluster information
###############################################
"HDD Status:"
$RubrikHDDStatus | Format-Table *
$RubrikHDDStatus | Out-GridView -Title "Rubrik HDD Status"
"Node Status:"
$RubrikNodeStatus | Format-Table *
$RubrikNodeStatus | Out-GridView -Title "Rubrik Node Status"
"Cluster Status: $ClusterStatus"
$RubrikClusterStatus | Format-Table *
$RubrikClusterStatus | Out-GridView -Title "Rubrik Cluster Status"
# Example Cluster Action:
IF ($ClusterStatus -ne "OK")
{
# Rubrik cluster is not healthy, I couldn't login, or it's dead man! 
# Do something here
}
# Example Node Action:
$RubrikBadNodes = $RubrikNodeStatus | Where-Object {($_.Status -ne "OK") -or ($_.NeedsInspection -eq "False")}
IF ($RubrikBadNodes -ne $null)
{
# Rubrik node is not healthy, do something here
"These nodes are not healthy:"
$RubrikBadNodes | Format-Table *
}
###############################################
# End of script
###############################################